from flask import Flask, render_template, request
import json
import csv
import datetime
import requests

app=Flask(__name__)

def date(s):
    s=s.split(".")
    a = str(datetime.datetime.now()).split()[0].split("-")
    if s[2]>a[0]:
        return True
    elif s[2]==a[0] and s[1]>a[1]:
        return True
    elif s[2]==a[0] and s[1]==a[1] and s[0]>=a[2]:
        return True
    # return a[2]+"."+a[1]+"."+a[0]
    return False

@app.route('/api/main')
def api_main():
    entities = []
    with open('files/main.csv', encoding="utf8") as csvfile:
        reader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for index, row in enumerate(reader):
            entities.append(row[0])
    return json.dumps({'data': entities })#, 200, {'Content-type':'application/json; charset=utf8'}

@app.route('/api/note/<user>')
def api_note(user):
    entities = []
    with open('files/'+user+'.csv', encoding="utf8") as csvfile:
        reader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for index, row in enumerate(reader):
            if date(row[0].split()[0]):
                entities.append([row[0].split()[0], " ".join(  row[0].split()[1:]  ), user+"q"+str(index)])
    return json.dumps({'data': entities})

@app.route('/api/delete/<n>')
def api_delete(n):
    n=n.split("q")
    user='files/'+n[0]+'.csv'
    entities = []
    with open(user, encoding="utf8") as csvfile:
        reader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for index, row in enumerate(reader):
            entities.append([row[0].split()[0], " ".join(row[0].split()[1:])])
    f = open(user, "w", encoding="utf8")
    for i in range(len(entities)):
        if i!=int(n[1]):
            x=" ".join(entities[i])
            f.write(x+"\n")
    f.close()
    return 'ok'

@app.route('/api/new/<n>')
def api_new_note(n):
    n=n.split("q")
    user='files/'+n[0]+'.csv'
    entities = []
    with open(user, encoding="utf8") as csvfile:
        reader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for index, row in enumerate(reader):
            entities.append([row[0].split()[0], " ".join(row[0].split()[1:])])
    f = open(user, "w", encoding="utf8")
    f.write(n[1]+" "+n[2]+"\n")
    for i in range(len(entities)):
        x=" ".join(entities[i])
        f.write(x+"\n")
    f.close()
    return 'ok'

@app.route('/api/change/<n>')
def api_change(n):
    n=n.split("q")
    user='files/'+n[0]+'.csv'
    entities = []
    with open(user, encoding="utf8") as csvfile:
        reader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for index, row in enumerate(reader):
            entities.append([row[0].split()[0], " ".join(row[0].split()[1:])])
    f = open(user, "w", encoding="utf8")
    for i in range(len(entities)):
        if i==int(n[1]):
            f.write(n[2]+" "+n[3]+"\n")
        else:
            x=" ".join(entities[i])
            f.write(x+"\n")
    f.close()
    return 'ok'

@app.route('/api/authorizations/<login>')
def api_authorizations(login):
    login=login.split("q")
    with open('files/users.csv', encoding="utf8") as csvfile:
        reader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for index, row in enumerate(reader):
            if row[0]==login[0] and row[1]==login[1]:
                return "True"
    return "False"

# здесь кончается api
# a="http://127.0.0.1:5000/api/delete/user1 0"
# print(requests.get(a).json())

@app.route('/')
def start():
    entities=api_main()
    entities=json.loads(entities)
    entities=entities["data"]
    return render_template('start.html', entities=entities)

@app.route('/authorizations', methods=['GET', 'POST'])
def authorizations():
    login=""
    password=""
    if request.method == "POST":
        for key, value in request.form.items():
            if key == 'login':
                login = value
            if key == 'password':
                password = value
    with open('files/users.csv', encoding="utf8") as csvfile:
        reader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for index, row in enumerate(reader):
            if login ==row[0] and password==row[1]:
                entities = api_main()
                entities = json.loads(entities)
                entities = entities["data"]
                entities = [login] + entities
                return render_template('main.html', entities=entities)
    return render_template(
        'authorizations.html',
    )

@app.route('/main/<login>')
def main(login):
    entities = api_main()
    entities = json.loads(entities)
    entities = entities["data"]
    entities=[login]+entities
    return render_template('main.html', entities=entities)

@app.route('/note/<login>')
def note(login):
    entities = api_note(login)
    entities = json.loads(entities)
    entities = entities["data"]
    entities=[login]+entities
    return render_template('note.html', entities=entities)

@app.route('/new_note/<user>', methods=['GET', 'POST'])
def new_note(user):
    date = ""
    note = ""
    if request.method == "POST":
        for key, value in request.form.items():
            if key == 'date':
                date = value
            if key == 'text':
                note = value
    if date!="" and note!="":
        api_new_note(user+"q"+date+"q"+note)
    entities=[user]
    return render_template('new_note.html', entities=entities)

@app.route('/change/<user>', methods=['GET', 'POST'])
def change(user):
    user, n=user.split("q")
    n=int(n)
    date = ""
    note = ""
    if request.method == "POST":
        for key, value in request.form.items():
            if key == 'date':
                date = value
            if key == 'text':
                note = value
    if date!="" and note!="":
        api_change(user+"q"+str(n)+"q"+date+"q"+note)

    entities = api_note(user)
    entities = json.loads(entities)
    entities = entities["data"]
    for i in entities:
        if i[2]==user+"q"+str(n):
            entities=i
    entities[2]=user+"q"+str(n)
    entities.append(user)
    print(entities)
    return render_template('change.html', entities=entities)

@app.route('/delete/<user>')
def delete(user):
    api_delete(user)
    login=user.split("q")[0]
    entities = api_note(login)
    entities = json.loads(entities)
    entities = entities["data"]
    entities = [login] + entities
    return render_template('note.html', entities=entities)

if __name__=='__main__':
    app.run(debug=True)